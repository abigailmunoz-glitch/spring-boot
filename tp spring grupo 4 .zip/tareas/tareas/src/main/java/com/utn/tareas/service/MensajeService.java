package com.utn.tareas.service;

public interface MensajeService {
    void mostrarBienvenida();
    void mostrarDespedida();
}