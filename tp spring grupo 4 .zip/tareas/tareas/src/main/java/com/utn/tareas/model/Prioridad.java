package com.utn.tareas.model;

public enum Prioridad {
    ALTA, MEDIA, BAJA
}