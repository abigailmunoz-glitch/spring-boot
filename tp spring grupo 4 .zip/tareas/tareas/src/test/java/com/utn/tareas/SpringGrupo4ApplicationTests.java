package com.utn.tareas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class SpringGrupo4ApplicationTests {

    @Test
    void contextLoads(){
    }

}